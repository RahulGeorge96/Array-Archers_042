import './App.css'
import { HeroSection } from './components/landingpage/herosection'
import { LoginPage } from './components/loginPage'
import { NavBar } from './components/navBar'
import { SignupPage } from './components/signupPage'

function App() {

  return (
    <>
    <NavBar/>
    <div className='marginfromtop'></div>
    <LoginPage/>
    {/* <SignupPage/> */}
    {/* <HeroSection/> */}
    </>
  )
}

export default App
